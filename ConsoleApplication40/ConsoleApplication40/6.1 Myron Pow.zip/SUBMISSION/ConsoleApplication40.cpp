/*Myron Pow, CS2B, 7/21/15, Dave Harden, ConsoleApplication40.cpp
Client file for creatures
*/

#include "balrog.h"
#include "cyberdemon.h"
#include "demon.h"
#include "elf.h"
#include "creature.h"
#include "human.h"
#include <cstdlib>
#include <ctime>
#include <iostream>

using namespace std;



int main() {
	srand(time(0));
	
	human h1;
	elf e1;
	cyberdemon c1;
	balrog b1;
	
	human h(20, 30);
	elf e(40, 50);
	cyberdemon c(60, 70);
	balrog b(80, 90);

	
	cout << "default human strength/hitpoints: " << h1.getStrength() << "/" << h1.getHitpoints() << endl;
	cout << "default elf strength/hitpoints: " << e1.getStrength() << "/" << e1.getHitpoints() << endl;
	cout << "default cyberdemon strength/hitpoints: " << c1.getStrength() << "/" << c1.getHitpoints() << endl;
	cout << "default balrog strength/hitpoints: " << b1.getStrength() << "/" << b1.getHitpoints() << endl;
	cout << "non-default human strength/hitpoints: " << h.getStrength() << "/" << h.getHitpoints() << endl;
	cout << "non-default elf strength/hitpoints: " << e.getStrength() << "/" << e.getHitpoints() << endl;
	cout << "non-default cyberdemon strength/hitpoints: " << c.getStrength() << "/" << c.getHitpoints() << endl;
	cout << "non-default balrog strength/hitpoints: " << b.getStrength() << "/" << b.getHitpoints() << endl;
	cout << endl << endl;

	cout << "Examples of " << h.getSpecies() << " damage: " << endl;
	for (int i = 0; i < 10; i++){
		int damage = h.getDamage();
		cout << " Total damage = " << damage << endl;
		cout << endl;
	}
	cout << endl;
	
	
	
	cout << "Examples of " << e.getSpecies() << " damage: " << endl;
	for (int i = 0; i < 10; i++){
		int damage = e.getDamage();
		cout << " Total damage = " << damage << endl;
		cout << endl;
	}
	cout << endl;
	
	
	
	cout << "Examples of " << c.getSpecies() << " damage: " << endl;
	for (int i = 0; i < 10; i++){
		int damage = c.getDamage();
		cout << " Total damage = " << damage << endl;
		cout << endl;
	}
	cout << endl;
	
	
	
	cout << "Examples of " << b.getSpecies() << " damage: " << endl;
	for (int i = 0; i < 10; i++){
		int damage = b.getDamage();
		cout << " Total damage = " << damage << endl;
		cout << endl;
	}
	cout << endl;
}

/*RUN
default human strength/hitpoints: 10/10
default elf strength/hitpoints: 10/10
default cyberdemon strength/hitpoints: 10/10
default balrog strength/hitpoints: 10/10
non-default human strength/hitpoints: 20/30
non-default elf strength/hitpoints: 40/50
non-default cyberdemon strength/hitpoints: 60/70
non-default balrog strength/hitpoints: 80/90


Examples of human damage:
The human attacks for 17 points!
 Total damage = 17

The human attacks for 12 points!
 Total damage = 12

The human attacks for 1 points!
 Total damage = 1

The human attacks for 17 points!
 Total damage = 17

The human attacks for 3 points!
 Total damage = 3

The human attacks for 16 points!
 Total damage = 16

The human attacks for 6 points!
 Total damage = 6

The human attacks for 19 points!
 Total damage = 19

The human attacks for 15 points!
 Total damage = 15

The human attacks for 13 points!
 Total damage = 13


Examples of elf damage:
The elf attacks for 29 points!
Magical attack inflicts 29 additional damage points!
 Total damage = 58

The elf attacks for 18 points!
Magical attack inflicts 18 additional damage points!
 Total damage = 36

The elf attacks for 40 points!
Magical attack inflicts 40 additional damage points!
 Total damage = 80

The elf attacks for 22 points!
 Total damage = 22

The elf attacks for 19 points!
 Total damage = 19

The elf attacks for 28 points!
Magical attack inflicts 28 additional damage points!
 Total damage = 56

The elf attacks for 37 points!
Magical attack inflicts 37 additional damage points!
 Total damage = 74

The elf attacks for 29 points!
 Total damage = 29

The elf attacks for 21 points!
 Total damage = 21

The elf attacks for 15 points!
Magical attack inflicts 15 additional damage points!
 Total damage = 30


Examples of cyberdemon damage:
The cyberdemon  attacks for 25 points!
 Total damage = 25

The cyberdemon  attacks for 41 points!
 Total damage = 41

The cyberdemon  attacks for 26 points!
Demonic attack inflicts 50 additional damage points!
 Total damage = 76

The cyberdemon  attacks for 6 points!
 Total damage = 6

The cyberdemon  attacks for 28 points!
 Total damage = 28

The cyberdemon  attacks for 21 points!
 Total damage = 21

The cyberdemon  attacks for 36 points!
 Total damage = 36

The cyberdemon  attacks for 16 points!
 Total damage = 16

The cyberdemon  attacks for 19 points!
 Total damage = 19

The cyberdemon  attacks for 9 points!
 Total damage = 9


Examples of balrog damage:
The balrog  attacks for 33 points!
Balrog speed attack inflicts 18 additional damage points!
 Total damage = 51

The balrog  attacks for 24 points!
Balrog speed attack inflicts 69 additional damage points!
 Total damage = 93

The balrog  attacks for 44 points!
Demonic attack inflicts 50 additional damage points!
Balrog speed attack inflicts 3 additional damage points!
 Total damage = 97

The balrog  attacks for 58 points!
Demonic attack inflicts 50 additional damage points!
Balrog speed attack inflicts 60 additional damage points!
 Total damage = 168

The balrog  attacks for 44 points!
Demonic attack inflicts 50 additional damage points!
Balrog speed attack inflicts 92 additional damage points!
 Total damage = 186

The balrog  attacks for 37 points!
Balrog speed attack inflicts 34 additional damage points!
 Total damage = 71

The balrog  attacks for 25 points!
Balrog speed attack inflicts 70 additional damage points!
 Total damage = 95

The balrog  attacks for 12 points!
Demonic attack inflicts 50 additional damage points!
Balrog speed attack inflicts 86 additional damage points!
 Total damage = 148

The balrog  attacks for 51 points!
Balrog speed attack inflicts 60 additional damage points!
 Total damage = 111

The balrog  attacks for 69 points!
Demonic attack inflicts 50 additional damage points!
Balrog speed attack inflicts 92 additional damage points!
 Total damage = 211


Press any key to continue . . .
*/